import os
import os.path
import sys

sys.path.append('/models/resources/viya/cc189cc2-a883-46ec-8a2b-52c91f96d000/')

import rapid_Efnetb2_food_tst

import settings_cc189cc2_a883_46ec_8a2b_52c91f96d000

settings_cc189cc2_a883_46ec_8a2b_52c91f96d000.pickle_path = '/models/resources/viya/cc189cc2-a883-46ec-8a2b-52c91f96d000/'

def score_record(image):
    "Output: food_label,msg"
    return rapid_Efnetb2_food_tst.scoreModel(image)

print(score_record(""))
