from torch import jit
import torch
from torchvision import transforms
import base64
from PIL import Image
import io


model = None

def scoreModel(image):
    "Output: food_label, msg"
    
    global model
    try:
        # load labels 
        with open("/modules/cc189cc2-a883-46ec-8a2b-52c91f96d000/class_names.txt", "r") as file:
            labels = file.read()
        labels = labels.split(",")

        # transform image data
        data_transforms = transforms.Compose([transforms.Resize(256),
                        transforms.CenterCrop(224),
                        transforms.ToTensor(),
                        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

        # read as string and decode base64
        my_byte = bytes(image, encoding="UTF-8")
        r = base64.decodebytes(my_byte)

        # convert into a numeric matrix
        image = Image.open(io.BytesIO(r)).convert("RGB")
        # transform into torch format
        image = data_transforms(image)
        
        if model is None:
            # load torch model
            model = jit.load("/modules/cc189cc2-a883-46ec-8a2b-52c91f96d000/food308_efnetb2_91.31%.pt", map_location=torch.device("cpu"))
        
        # predict the index
        _,preds = torch.max(model(image[None, ...]), 1)
        food_label = labels[preds[0]]
        msg = "success"
    except Exception as e:
        food_label = "-1"
        msg = str(e)
    return food_label, msg